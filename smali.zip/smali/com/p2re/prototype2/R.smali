###### Class com.p2re.prototype2.R is created by jadx
###### Class com.p2re.prototype2.R.mipmap is created by jadx