package com.p2re.prototype2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import java.io.File;
import java.io.FileOutputStream;

/* JADX INFO: loaded from: classes.dex */
public class FolderPicker extends Activity {
    private static final int PICK = 1;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            return;
        }
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.putExtra("android.provider.extra.SHOW_ADVANCED", true);
        try {
            startActivityForResult(intent, PICK);
        } catch (Exception unused) {
            finish();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        String strTreeToPath;
        if (i == PICK && i2 == -1 && intent != null && intent.getData() != null && (strTreeToPath = TreeToPath(intent.getData())) != null) {
            Save(strTreeToPath);
        }
        finish();
    }

    static String TreeToPath(Uri uri) {
        String path;
        try {
            if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) {
                return null;
            }
            String treeDocumentId = DocumentsContract.getTreeDocumentId(uri);
            int iIndexOf = treeDocumentId.indexOf(58);
            String strSubstring = iIndexOf < 0 ? treeDocumentId : treeDocumentId.substring(0, iIndexOf);
            String strSubstring2 = iIndexOf < 0 ? "" : treeDocumentId.substring(iIndexOf + PICK);
            if ("primary".equalsIgnoreCase(strSubstring)) {
                path = Environment.getExternalStorageDirectory().getPath();
            } else {
                path = "/storage/" + strSubstring;
            }
            if (strSubstring2.isEmpty()) {
                return path;
            }
            return path + "/" + strSubstring2;
        } catch (Exception unused) {
            return null;
        }
    }

    private void Save(String str) {
        File externalFilesDir = getExternalFilesDir(null);
        if (externalFilesDir == null) {
            return;
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(new File(externalFilesDir, "game_folder.txt"));
            try {
                fileOutputStream.write(str.getBytes("UTF-8"));
                fileOutputStream.close();
            } finally {
            }
        } catch (Exception unused) {
        }
    }
}
